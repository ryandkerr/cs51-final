If you have Python installed on your machine, just open up a command prompt and navigate to this directory. Once there, enter �python connectFour.py� to run the interactive game, or �python cpuFour.py� to watch two AIs duke it out. These commands will both compile and run the code, so no need to worry about "make". If you don�t have Python installed on your machine, see the installation guide linked below.
https://wiki.python.org/moin/BeginnersGuide/Download

For more information, check out our video!
https://www.youtube.com/watch?v=g4VX8Rd2Z70&feature=youtu.be